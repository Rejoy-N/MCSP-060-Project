#include <stdio.h>

// main prints "hello world" to standard output.
int main(int argc, char **argv) {
	printf("hello world\n");
	return 0;
}
