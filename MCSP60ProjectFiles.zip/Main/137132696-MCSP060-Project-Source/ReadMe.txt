MCSP-060 Prject for Enrolment ID: 137132696 ReadMe file

1. Install Go
2. install Sqlite3
3. Generate TLS certifcates and place them in TLS folder.
4. Run web app in localhost:8090
5. Admin username="admin" password ="admin" 
